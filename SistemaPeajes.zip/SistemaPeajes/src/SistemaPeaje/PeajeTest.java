package SistemaPeaje;

import org.junit.jupiter.api.Test;

public class PeajeTest {
    @Test
    void testAddVehiculo() {

    }

    @Test
    void testCalcularPeaje() {

    }

    @Test
    void testGetDepartamento() {

    }

    @Test
    void testGetNombre() {

    }
}
